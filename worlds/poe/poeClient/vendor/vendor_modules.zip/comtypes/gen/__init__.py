# comtypes.gen package, directory for generated files.
